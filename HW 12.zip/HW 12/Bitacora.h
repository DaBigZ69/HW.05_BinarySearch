//Bitacora.h

#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "Log.h"

using namespace std;

class Bitacora {
public:
    vector<Log> logs;
    void leerArchivo(const string& nameFile);
    void showAll();
    void ordenar();
};
