// Main HW.12
// Gerardo Alberto Mendoza Castillo A01666338
// Fabian Lopez Perez A01661836

// Test file:
// bitacora.txt

// Test inputs:
// 423.2.230.77:6166
// 165.7.908.43:7653
// 311.49.840.89:4145

#include "Bitacora.h"
#include "Log.h"
#include <iostream>
#include <vector>
#include <sstream>
#include <unordered_map>

using namespace std;

long long changeip(string ip);

vector<vector<long long>> build_binary_tree(const vector<long long>& number_set) {
    vector<vector<long long>> binary_tree(1, vector<long long>(4, 0));
    
    cout << "\nCreating Binary Search Tree...\n\n";
    binary_tree[0][0] = number_set[0];
    binary_tree[0][3] = 1;

    for (int i = 1; i < number_set.size(); i++) {
        int level = 2, node_index = 0;
        bool active_comparison = true;

        while (active_comparison) {
            if (binary_tree[node_index][1] == 0 && number_set[i] < binary_tree[node_index][0]) {
                binary_tree[node_index][1] = number_set[i];
                active_comparison = false;
            }
            else if (binary_tree[node_index][2] == 0 && number_set[i] > binary_tree[node_index][0]) {
                binary_tree[node_index][2] = number_set[i];
                active_comparison = false;
            }
            else {
                if (number_set[i] < binary_tree[node_index][0]) {
                    for (size_t j = 1; j < binary_tree.size(); j++) {
                        if (binary_tree[j][0] == binary_tree[node_index][1]) {
                            node_index = j;
                            break;
                        }
                    }
                    level++;
                }
                else if (number_set[i] > binary_tree[node_index][0]) {
                    for (size_t j = 1; j < binary_tree.size(); j++) {
                        if (binary_tree[j][0] == binary_tree[node_index][2]) {
                            node_index = j;
                            break;
                        }
                    }
                    level++;
                }
            }
        }

        binary_tree.push_back(vector<long long>(4, 0));
        binary_tree[binary_tree.size() - 1][0] = number_set[i];
        binary_tree[binary_tree.size() - 1][3] = level;
    }

    return binary_tree;
}

void show_tree_details(const vector<vector<long long>>& binary_tree,
                       const unordered_map<long long, Log*>& ip_to_log) {
    cout << "\nBinary Tree Details\n";
    for (size_t i = 0; i < binary_tree.size(); i++) {
        long long ip_num = binary_tree[i][0];
        cout << "\nNode: " << ip_num << " (IP transformed to integer)"
             << "\n+ Position in tree: Level " << binary_tree[i][3];

        if (ip_to_log.count(ip_num)) {
            Log* log = ip_to_log.at(ip_num);
            cout << "\n+ Original log: " << log->month << " " << log->day << " " << log->time
                 << " " << log->ip << " " << log->motive;
        }

        if (i == 0)
            cout << "\n+ Root node";
        else {
            for (size_t j = 0; j < binary_tree.size(); j++) {
                if (binary_tree[j][1] == ip_num || binary_tree[j][2] == ip_num) {
                    cout << "\n+ Parent node: " << binary_tree[j][0];
                    break;
                }
            }
        }

        if (binary_tree[i][1] != 0 && binary_tree[i][2] != 0)
            cout << "\n+ Produced nodes: " << binary_tree[i][1] << " (Left), " << binary_tree[i][2] << " (Right)\n";
        else if (binary_tree[i][1] != 0)
            cout << "\n+ Produced node: " << binary_tree[i][1] << " (Left)\n";
        else if (binary_tree[i][2] != 0)
            cout << "\n+ Produced node: " << binary_tree[i][2] << " (Right)\n";
        else
            cout << "\n+ Zero produced nodes\n";
    }
}

void search_ip(const vector<vector<long long>>& binary_tree,
               const unordered_map<long long, Log*>& ip_to_log) {
    string ip_input;
    cout << "\nPlease enter an IP address to search: ";
    cin >> ip_input;

    long long ip_num = 0;
    try {
        ip_num = changeip(ip_input);
    } catch (...) {
        cout << "\nNot found\n";
        return;
    }

    bool found = false;

    for (size_t i = 0; i < binary_tree.size(); i++) {
        if (binary_tree[i][0] == ip_num) {
            found = true;
            cout << "\nMatch found:\n";
            cout << "Node: " << ip_num << " (IP transformed to integer)"
                 << "\n+ Position in tree: Level " << binary_tree[i][3];

            if (ip_to_log.count(ip_num)) {
                Log* log = ip_to_log.at(ip_num);
                cout << "\n+ Original log: " << log->month << " " << log->day << " " << log->time
                     << " " << log->ip << " " << log->motive;

                cout << "\n\nLog Details:";
                cout << "\n- Date: " << log->month << " " << log->day;
                cout << "\n- Time: " << log->time;
                cout << "\n- IP: " << log->ip;
                cout << "\n- Event description: " << log->motive;
            }

            if (i == 0)
                cout << "\n+ Root node";
            else {
                for (size_t j = 0; j < binary_tree.size(); j++) {
                    if (binary_tree[j][1] == ip_num || binary_tree[j][2] == ip_num) {
                        cout << "\n+ Parent node: " << binary_tree[j][0];
                        break;
                    }
                }
            }

            if (binary_tree[i][1] != 0 && binary_tree[i][2] != 0)
                cout << "\n+ Produced nodes: " << binary_tree[i][1] << " (Left), " << binary_tree[i][2] << " (Right)\n";
            else if (binary_tree[i][1] != 0)
                cout << "\n+ Produced node: " << binary_tree[i][1] << " (Left)\n";
            else if (binary_tree[i][2] != 0)
                cout << "\n+ Produced node: " << binary_tree[i][2] << " (Right)\n";
            else
                cout << "\n+ Zero produced nodes\n";

            break;
        }
    }

    if (!found) {
        cout << "\nNot found\n";
    }
}

int main() {
    Bitacora bitacora;

    vector<long long> ip_vector;
    unordered_map<long long, Log*> ip_to_log;
    vector<vector<long long>> binary_tree;

    bool tree_created = false;
    bool exit_program = false;

    while (!exit_program) {
        int choice;
        cout << "\nMenu:\n";
        cout << "[1] Create and display Binary Search Tree\n";
        cout << "[2] Search for data corresponding to an IP address\n";
        cout << "[3] Exit\n";
        cout << "Please enter your choice (1, 2, or 3): ";
        cin >> choice;

        if (choice == 1 && !tree_created) {
            string file_name;
            cout << "\nPlease enter the name of the .txt file to import: ";
            cin >> file_name;
            bitacora.leerArchivo(file_name);

            for (size_t i = 0; i < bitacora.logs.size(); ++i) {
                long long ip_num = changeip(bitacora.logs[i].ip);
                ip_vector.push_back(ip_num);
                ip_to_log[ip_num] = &bitacora.logs[i];
            }
            binary_tree = build_binary_tree(ip_vector);
            show_tree_details(binary_tree, ip_to_log);
            tree_created = true;
        }
        else if (choice == 1 && tree_created) {
            cout << "\nTree already created\n";
        }
        else if (choice == 2 && tree_created) {
            search_ip(binary_tree, ip_to_log);
        }
        else if (choice == 2 && !tree_created) {
            cout << "\nTree not yet created\n";
        }
        else if (choice == 3) {
            exit_program = true;
        }
        else {
            cout << "\nInvalid option, please try again\n";
        }
    }

    return 0;
}
