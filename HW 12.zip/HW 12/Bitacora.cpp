//Bitacora.cpp
#include "Bitacora.h"

using namespace std;

void Bitacora::leerArchivo(const string& nameFile) {
    ifstream file(nameFile);
    if (!file) {
        cout << "Error al abrir el archivo" << endl;
        return;
    }

    string month, time, ip, motive;
    unsigned int day;

    while (file >> month >> day >> time >> ip) {
        getline(file, motive);
        logs.push_back(Log(month, day, time, ip, motive));
    }

    file.close();
}
void Bitacora::ordenar() {
    sort(logs.begin(), logs.end(), [](const Log& a, const Log& b) {
        return a.ip < b.ip;
        });
}

void Bitacora::showAll() {
    for (const auto& l : logs) {
        l.show();
    }
}



